/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;
import java.util.List;
/**
 *
 * @author HB Laptop Point
 */
public class IDGenerator {

    public static String generateID(String prefix, String fileName) {
        List<String> lines = FileHelper.readFile(fileName);
        int max = 0;

        for (String line : lines) {
            String[] parts = line.split(",");
            if (parts.length > 0 && parts[0].startsWith(prefix)) {
                String numStr = parts[0].substring(prefix.length());
                try {
                    int num = Integer.parseInt(numStr);
                    if (num > max) max = num;
                } catch (NumberFormatException e) {
                        System.out.println(e.getMessage());
                }
            }
        }

        int newIdNum = max + 1;
        return prefix + String.format("%03d", newIdNum);
    }
}
