/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;
import java.util.List;
/**
 *
 * @author HB Laptop Point
 */
public class Validator {

    public static boolean isEmpty(String field) {
        return field == null || field.trim().isEmpty();
    }

    public static boolean isValidEmail(String email) {
        return email != null && email.contains("@") && email.contains(".");
    }

    public static boolean isDuplicateEmail(String email, String fileName) {
        List<String> users = FileHelper.readFile(fileName);
        for (String line : users) {
            String[] parts = line.split(",");
            if (parts.length >= 3 && parts[2].equalsIgnoreCase(email)) {
                return true;
            }
        }
        return false;
    }
}
