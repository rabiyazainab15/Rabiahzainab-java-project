/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author HB Laptop Point
 */
public class FileHelper {
    public static List<String> readFile(String fileName) {
        List<String> lines = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return lines;
    }

    public static void writeFile(String fileName, List<String> lines) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(fileName))) {
            for (String line : lines) {
                pw.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }

    public static void appendToFile(String fileName, String line) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(fileName, true))) {
            pw.println(line);
        } catch (IOException e) {
            System.out.println("Error appending to file: " + e.getMessage());
        }
    }

    public static void deleteLine(String fileName, String id) {
        List<String> lines = readFile(fileName);
        List<String> newLines = new ArrayList<>();
        for (String line : lines) {
            if (!line.startsWith(id + ",")) {
                newLines.add(line);
            }
        }
        writeFile(fileName, newLines);
    }

    public static void updateLine(String fileName, String id, String newLine) {
        List<String> lines = readFile(fileName);
        List<String> newLines = new ArrayList<>();
        for (String line : lines) {
            if (line.startsWith(id + ",")) {
                newLines.add(newLine);
            } else {
                newLines.add(line);
            }
        }
        writeFile(fileName, newLines);
    }

    public static void appendLine(String datauserstxt, String line) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static void replaceFile(String datauserstxt, List<String> lines) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
