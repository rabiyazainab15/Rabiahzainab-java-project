/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;
import java.util.List;
/**
 *
 * @author HB Laptop Point
 */
public class TestUtils {
    public static void main(String[] args) {
        String usersFile = "C:\\Users\\HB Laptop Point\\OneDrive\\Documents\\NetBeansProjects\\Learnify\\data\\users.txt";

        String newId = IDGenerator.generateID("U", usersFile);

        String newUser = newId + ", Azan ,azan@email.com,pass123,Student";
        FileHelper.appendToFile(usersFile, newUser);

        List<String> users = FileHelper.readFile(usersFile);
        System.out.println("All Users:");
        for (String u : users) {
            System.out.println(u);
        }

        System.out.println("Email valid? " + Validator.isValidEmail("azan@email.com"));
        System.out.println("Email duplicate? " + Validator.isDuplicateEmail("azan@email.com", usersFile));

        FileHelper.updateLine(usersFile, newId, newId + ",Azan ,azan@email.com,pass123,Student");
    }
}
