
package gui;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.io.File;
import java.awt.Desktop;
import java.io.IOException;

public class StudentDashboard extends javax.swing.JFrame {
    
    private final String userEmail; 

    public StudentDashboard() {
        this.userEmail = "test@student.com";
        initComponents();
        welcomeLabel.setText("Welcome, " + userEmail);
        loadCourses(); 
        loadAnnouncements();
        loadMaterials();
        loadAssignments();
        loadGrades();
    }
    
    private void loadCourses() {
        DefaultTableModel model = (DefaultTableModel) coursesTable.getModel();
        model.setRowCount(0); 
            String userId = "";
     for (String line : utils.FileHelper.readFile("data/users.txt")) {
        String[] parts = line.split(",", -1);
        if (parts.length >= 5 && parts[2].equalsIgnoreCase(userEmail)) {
            userId = parts[0]; // found matching ID
            break;
        }
    }
        try {
            for (String line : utils.FileHelper.readFile("data/enrollments.txt")) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 2 && parts[0].equalsIgnoreCase(userId)) {
                    String courseId = parts[1];

                    String courseName = "";
                    String instructor = "";
                    for (String cLine : utils.FileHelper.readFile("data/courses.txt")) {
                        String[] cParts = cLine.split(",", -1);
                        if (cParts.length >= 3 && cParts[0].equalsIgnoreCase(courseId)) {
                            courseName = cParts[1];
                            instructor = cParts[2];
                            break;
                        }
                    }

                    model.addRow(new Object[]{courseId, courseName, instructor});
                }
            }

            if (model.getRowCount() == 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "No courses found.");
            }

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error loading courses: " + e.getMessage());
        }
    }

    private void loadAnnouncements() {
        DefaultTableModel model = (DefaultTableModel) announcementsTable.getModel();
        model.setRowCount(0);
        String userId = "";
for (String line : utils.FileHelper.readFile("data/users.txt")) {
    String[] parts = line.split(",", -1);
    if (parts.length >= 5 && parts[2].equalsIgnoreCase(userEmail)) {
        userId = parts[0]; // found matching ID
        break;
    }
}

        try {
            java.util.Set<String> enrolledCourses = new java.util.HashSet<>();
            for (String line : utils.FileHelper.readFile("data/enrollments.txt")) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 2 && parts[0].equalsIgnoreCase(userId)) {
                    enrolledCourses.add(parts[1]);
                }
            }

            for (String line : utils.FileHelper.readFile("data/announcements.txt")) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 5 && enrolledCourses.contains(parts[1])) {
                    String courseId = parts[1];
                    String postedBy = parts[2];
                    String message = parts[3];
                    String date = parts[4];

                    model.addRow(new Object[]{courseId, message, postedBy, date});
                }
            }

            if (model.getRowCount() == 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "No announcements found.");
            }

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error loading announcements: " + e.getMessage());
        }
    }
    
    private void loadMaterials() {
    DefaultTableModel model = (DefaultTableModel) materialsTable.getModel();
    model.setRowCount(0);
    String userId = "";
for (String line : utils.FileHelper.readFile("data/users.txt")) {
    String[] parts = line.split(",", -1);
    if (parts.length >= 5 && parts[2].equalsIgnoreCase(userEmail)) {
        userId = parts[0]; // found matching ID
        break;
    }
}
    try {
        java.util.Set<String> enrolledCourses = new java.util.HashSet<>();
        for (String line : utils.FileHelper.readFile("data/enrollments.txt")) {
            String[] parts = line.split(",", -1);
            if (parts.length >= 2 && parts[0].equalsIgnoreCase(userId)) {
                enrolledCourses.add(parts[1]);
            }
        }

        for (String line : utils.FileHelper.readFile("data/materials.txt")) {
            String[] parts = line.split(",", -1);
            if (parts.length >= 5 && enrolledCourses.contains(parts[1])) {
                String courseId = parts[1];
                String title = parts[2];
                String type = parts[3];
                String filePath = parts[4];

                model.addRow(new Object[]{courseId, title, type, filePath});
            }
        }

        if (model.getRowCount() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "No materials found.");
        }

    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error loading materials: " + e.getMessage());
    }
}
     
    private void loadAssignments() {
    DefaultTableModel model = (DefaultTableModel) assignmentsTable.getModel();
    model.setRowCount(0);

    try {
        // 🔹 Step 1: Lookup user ID from email
        String userId = "";
        for (String line : utils.FileHelper.readFile("data/users.txt")) {
            String[] parts = line.split(",", -1);
            if (parts.length >= 5 && parts[2].equalsIgnoreCase(userEmail)) {
                userId = parts[0];
                break;
            }
        }

        // 🔹 Step 2: Collect enrolled courses
        java.util.Set<String> enrolledCourses = new java.util.HashSet<>();
        for (String line : utils.FileHelper.readFile("data/enrollments.txt")) {
            String[] parts = line.split(",", -1);
            if (parts.length >= 2 && parts[0].equalsIgnoreCase(userId)) {
                enrolledCourses.add(parts[1]);
            }
        }

        // 🔹 Step 3: Load assignments for enrolled courses
        for (String line : utils.FileHelper.readFile("data/assignments.txt")) {
            String[] parts = line.split(",", -1);
            if (parts.length >= 5 && enrolledCourses.contains(parts[1])) {
                String courseId = parts[1];
                String title = parts[2];
                String marks = parts[3];
                String dueDate = parts[4];

                model.addRow(new Object[]{courseId, title, dueDate, marks});
            }
        }

        if (model.getRowCount() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "No assignments found.");
        }

    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error loading assignments: " + e.getMessage());
    }
}
    
    private void loadGrades() {
        DefaultTableModel model = (DefaultTableModel) gradesTable.getModel();
        model.setRowCount(0);

        String userId = "";
    for (String line : utils.FileHelper.readFile("data/users.txt")) {
    String[] parts = line.split(",", -1);
    if (parts.length >= 5 && parts[2].equalsIgnoreCase(userEmail)) {
        userId = parts[0]; // found matching ID
        break;
    }
}
        
        try {
            for (String line : utils.FileHelper.readFile("data/grades.txt")) {
                String[] parts = line.split(",", -1);
                if (parts.length >= 4 && parts[0].equalsIgnoreCase(userId)) {
                    String courseId = parts[1];
                    String grade = parts[2];
                    String gpa = parts[3];

                // 🔹 Look up course name from courses.txt
                    String courseName = "";
                    for (String cLine : utils.FileHelper.readFile("data/courses.txt")) {
                        String[] cParts = cLine.split(",", -1);
                        if (cParts.length >= 3 && cParts[0].equalsIgnoreCase(courseId)) {
                            courseName = cParts[1]; // use courseName instead of courseId
                            break;
                        }
                    }   

                    model.addRow(new Object[]{courseName, grade, gpa});
                }
            }

            if (model.getRowCount() == 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "No grades found.");
            }

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Error loading grades: " + e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        welcomeLabel = new javax.swing.JLabel();
        logoutButton = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        coursesTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        announcementsTable = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        materialsTable = new javax.swing.JTable();
        downloadButton = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        assignmentsTable = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        gradesTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Student DashBoard");
        setResizable(false);

        welcomeLabel.setText("Welcome ! Student");

        logoutButton.setText("Logout");
        logoutButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutButtonActionPerformed(evt);
            }
        });

        jTabbedPane1.setName(""); // NOI18N

        coursesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Course ID", "Course Name", "Instructor"
            }
        ));
        jScrollPane1.setViewportView(coursesTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 466, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Courses", jPanel1);

        announcementsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Course ID", "Message", "Posted By ", "Date"
            }
        ));
        jScrollPane2.setViewportView(announcementsTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Announcements", jPanel2);

        materialsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Course ID", "Title", "Type", "File Path"
            }
        ));
        jScrollPane3.setViewportView(materialsTable);

        downloadButton.setText("Download");
        downloadButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                downloadButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(195, 195, 195)
                .addComponent(downloadButton, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(downloadButton)
                .addGap(59, 59, 59))
        );

        jTabbedPane1.addTab("Materials", jPanel3);

        assignmentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Course ID", "Title ", "Due Date", "Status"
            }
        ));
        jScrollPane4.setViewportView(assignmentsTable);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Assignments", jPanel4);

        gradesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Course Name", "Grade", "GPA"
            }
        ));
        jScrollPane5.setViewportView(gradesTable);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jTabbedPane1.addTab("Grades", jPanel5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(180, 180, 180)
                .addComponent(welcomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logoutButton)
                .addGap(15, 15, 15))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logoutButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(welcomeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void logoutButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutButtonActionPerformed
                                             
    this.dispose(); 
    new LoginForm().setVisible(true); 

    }//GEN-LAST:event_logoutButtonActionPerformed

    private void downloadButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_downloadButtonActionPerformed
        int selectedRow = materialsTable.getSelectedRow();
        if (selectedRow == -1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a material to download.");
            return;
        }

        String filePath = materialsTable.getValueAt(selectedRow, 3).toString(); // column 3 = File Path

        java.io.File file = new java.io.File(filePath);
    if (!file.exists()) {
        javax.swing.JOptionPane.showMessageDialog(this, "File not found: " + filePath);
        return;
    }
    try {
        java.awt.Desktop.getDesktop().open(file);
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Unable to open file: " + e.getMessage());
}
    }//GEN-LAST:event_downloadButtonActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new StudentDashboard().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable announcementsTable;
    private javax.swing.JTable assignmentsTable;
    private javax.swing.JTable coursesTable;
    private javax.swing.JButton downloadButton;
    private javax.swing.JTable gradesTable;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JButton logoutButton;
    private javax.swing.JTable materialsTable;
    private javax.swing.JLabel welcomeLabel;
    // End of variables declaration//GEN-END:variables
}
